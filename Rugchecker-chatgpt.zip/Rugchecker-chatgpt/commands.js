const { doCoreChecks, doExhaustiveChecks } = require("./checks");
const { computeScore, formatSummary, formatFullReport } = require("./scoring");
const { enqueueForManualReview } = require("./manual");

async function runChecksCommand(mintAddress, opts = { exhaustive: false }) {
  // Run core minimum checks
  const core = await doCoreChecks(mintAddress); // mint/freeze, supply, top holders
  let extra = {};
  if (opts.exhaustive) {
    extra = await doExhaustiveChecks(mintAddress); // liquidity, program logs, honeypot tests (sim)
  }
  const combined = { ...core, ...extra };
  const score = computeScore(combined);
  const summaryMarkdown = formatSummary(mintAddress, combined, score).summaryMarkdown;
  const fullReportMarkdown = formatFullReport(mintAddress, combined, score).fullReportMarkdown;

  // Auto queue for manual review if high score
  if (score >= (parseInt(process.env.SCORE_BLOCK_THRESHOLD || "80"))) {
    await enqueueForManualReview(mintAddress, combined, score);
  }

  return {
    score,
    summaryMarkdown,
    fullReportMarkdown,
    raw: combined
  };
}

async function healthCheck() {
  // Minimal worker health: could check Redis, DB connectivity, RPC ping
  const { testRpc } = require("./utils");
  const rpcStatus = await testRpc();
  return { rpc: rpcStatus };
}

module.exports = { runChecksCommand, healthCheck };
