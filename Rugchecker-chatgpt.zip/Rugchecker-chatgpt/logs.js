const axios = require("axios");

async function parseProgramLogs(mintPub, opts = {}) {
  const heliusKey = opts.heliusKey;
  if (!heliusKey) {
    // Without Helius we rely on RPC traced transactions which is slower
    return { warning: "No Helius key provided - limited logs parsing" };
  }
  try {
    const url = `https://api.helius.xyz/v0/addresses/${mintPub.toBase58()}/transactions?api-key=${heliusKey}`;
    const r = await axios.get(url, { timeout: 10000 });
    const txs = r.data || [];
    const suspicious = [];
    for (const tx of txs) {
      const text = JSON.stringify(tx).toLowerCase();
      if (text.includes("setauthority") || text.includes("mintto") || text.includes("withdraw") || text.includes("setfee") || text.includes("settax") || text.includes("freezeaccount")) {
        suspicious.push({ signature: tx.signature, snippet: text.slice(0, 1200) });
      }
    }
    return { source: "helius", suspicious };
  } catch (e) {
    return { error: e.message };
  }
}

module.exports = { parseProgramLogs };
