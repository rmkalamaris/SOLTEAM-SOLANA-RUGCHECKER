# SOLTEAM Rugpull Checker Bot

## Project Overview
This is a Solana rugpull checker Telegram bot that analyzes SPL tokens for potential risks. The bot performs both quick scans and exhaustive scans that check:
- Mint/freeze authority status  
- Token supply and distribution
- Top holder concentrations
- Liquidity pool analysis
- Program log parsing
- Optional microtrade simulation

## Current Status
- **Language**: Node.js 20
- **Type**: Backend Telegram Bot (no frontend)
- **Dependencies**: All installed via npm
- **Deployment**: Ready for configuration

## Architecture
- `bot.js` - Main Telegram bot interface
- `commands.js` - Bot command handlers  
- `checks.js` - Core on-chain analysis logic
- `scoring.js` - Risk scoring and report formatting
- `worker.js` - Background job queue (Redis-based, made optional)
- `manual.js` - Manual review queue for high-risk tokens
- `notifier.js` - Admin notification system
- Various utilities for on-chain data fetching

## Recent Changes
- **2025-09-26**: Initial import and setup completed
  - Fixed Redis/BullMQ incompatibility with Upstash by making queue system optional
  - Configured Node.js workflow for the bot
  - Set up project dependencies

## Required Configuration
The bot requires several environment variables to function:

### Critical (Required)
- `TELEGRAM_TOKEN` - Your Telegram bot token from @BotFather
- `ADMIN_CHAT_ID` - Your Telegram user ID for admin alerts
- `RPC_URL` - Solana RPC endpoint (defaults to public mainnet)

### Optional (Recommended)  
- `HELIUS_API_KEY` - For faster Solana data access
- `DATABASE_URL` - PostgreSQL for persistence (already configured)
- `REDIS_URL` - For background jobs (note: Upstash incompatible with BullMQ)
- `SCORE_BLOCK_THRESHOLD` - Risk score threshold (default: 80)

## User Preferences
- Prefers working applications over mock/placeholder data
- Values security best practices for API key management
- Wants clear documentation of setup requirements

## Next Steps
1. Configure required secrets (TELEGRAM_TOKEN, ADMIN_CHAT_ID, RPC_URL)  
2. Test bot functionality with sample token addresses
3. Configure deployment settings
4. Consider Redis alternative if background jobs needed

## Bot Commands
- `/check <MINT_ADDRESS>` - Quick rugpull scan
- `/scan <MINT_ADDRESS>` - Exhaustive analysis  
- `/health` - Worker status (admin only)
- `/whitelist <MINT_ADDRESS>` - Whitelist token (admin only)