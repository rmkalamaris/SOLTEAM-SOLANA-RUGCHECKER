const { Pool } = require("pg");

let pool = null;
if (process.env.DATABASE_URL) {
  pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
}

async function enqueueForManualReview(mint, payload, score) {
  const record = {
    mint,
    score,
    payloadSnippet: JSON.stringify(payload).slice(0, 8000),
    ts: new Date().toISOString()
  };
  console.warn("ENQUEUE MANUAL REVIEW:", record);
  if (pool) {
    try {
      await pool.query(
        `INSERT INTO manual_reviews(mint,score,payload,created_at) VALUES($1,$2,$3,$4)`,
        [mint, score, record.payloadSnippet, new Date()]
      );
    } catch (e) {
      console.error("DB insert failed:", e.message);
    }
  }
}

module.exports = { enqueueForManualReview };
