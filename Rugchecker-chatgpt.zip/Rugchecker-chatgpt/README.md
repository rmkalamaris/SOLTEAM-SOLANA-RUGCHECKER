# SOLTEAM Rugpull Checker (starter)

This is a modular Node.js starter project for a Solana rugpull-checker Telegram bot (SOLTEAM).
It implements core on-chain checks (mint/freeze authority, supply, top holders) and scaffolds
exhaustive checks (liquidity/pool heuristics, program log parsing, honeypot simulation).
Microtrade execution is disabled by default for safety.

## Quick start

1. Create a Replit Node.js project or clone locally.
2. Copy `.env.example` to `.env` and fill required keys:
   - TELEGRAM_TOKEN
   - ADMIN_CHAT_ID
   - RPC_URL (default public URL is included)
   - Optional: HELIUS_API_KEY, DATABASE_URL, REDIS_URL

3. Install deps:
```
npm install
```

4. Run:
```
node bot.js
```

5. Commands:
- `/check <MINT_ADDRESS>` - quick scan
- `/scan <MINT_ADDRESS>` - exhaustive scan (uses more RPC & optional microtrade)

## Notes
- Do NOT commit `.env` or any secret keys.
- Test on small tokens / testnet before enabling microtrades.
