require("dotenv").config();
const { Telegraf } = require("telegraf");
const { createWorkerQueue } = require("./worker");
const { runChecksCommand, healthCheck } = require("./commands");
const { sendAdminAlert } = require("./notifier");

const bot = new Telegraf(process.env.TELEGRAM_TOKEN);
const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID;

// Basic commands
bot.start((ctx) => ctx.reply("Welcome to SOLTEAM Rugpull Checker. Use /help."));
bot.help((ctx) => {
  ctx.reply(
    "/check <MINT_ADDRESS> - run full rugpull scan (fast)\n" +
    "/scan <MINT_ADDRESS> - run exhaustive scan (uses more RPC & optional microtrade)\n" +
    "/health - get worker status (admin only)\n" +
    "/whitelist <MINT_ADDRESS> - admin only - whitelist token"
  );
});

// /check - quick scan
bot.command("check", async (ctx) => {
  const parts = ctx.message.text.split(/\s+/);
  if (parts.length < 2) return ctx.reply("Usage: /check <SPL_MINT_ADDRESS>");
  const mint = parts[1];
  ctx.reply(`⏳ Running quick scan for ${mint}...`);
  try {
    const result = await runChecksCommand(mint, { exhaustive: false });
    await ctx.replyWithMarkdown(result.summaryMarkdown);
    if (result.score >= (parseInt(process.env.SCORE_BLOCK_THRESHOLD || "80"))) {
      await ctx.replyWithMarkdown(`⚠️ *Recommendation:* Do NOT buy — token flagged as HIGH RISK (score ${result.score}).`);
    }
  } catch (e) {
    console.error(e);
    await ctx.reply("❌ Error running check: " + (e.message || e));
    if (ADMIN_CHAT_ID) sendAdminAlert(`Error running /check: ${e.message || e}`);
  }
});

// /scan - exhaustive scan (more RPC calls, may run microtrade simulation if enabled)
bot.command("scan", async (ctx) => {
  const parts = ctx.message.text.split(/\s+/);
  if (parts.length < 2) return ctx.reply("Usage: /scan <SPL_MINT_ADDRESS>");
  const mint = parts[1];
  ctx.reply(`⏳ Running exhaustive scan (will check liquidity, holders, program logs, optional microtrade) for ${mint}...`);
  try {
    const result = await runChecksCommand(mint, { exhaustive: true });
    await ctx.replyWithMarkdown(result.fullReportMarkdown);
  } catch (e) {
    console.error(e);
    await ctx.reply("❌ Error running exhaustive scan: " + (e.message || e));
    if (ADMIN_CHAT_ID) sendAdminAlert(`Error running /scan: ${e.message || e}`);
  }
});

// Admin-only health
bot.command("health", async (ctx) => {
  if (String(ctx.from.id) !== String(ADMIN_CHAT_ID)) return ctx.reply("Unauthorized.");
  const s = await healthCheck();
  ctx.reply(JSON.stringify(s, null, 2));
});

// Hook to create worker queue (background jobs for streaming or heavy scans)
createWorkerQueue(); // initializes workers, queue listeners etc.

// Launch bot
bot.launch().then(() => {
  console.log("🚀 SOLTEAM Rugpull Checker Bot running.");
  if (ADMIN_CHAT_ID) {
    bot.telegram.sendMessage(ADMIN_CHAT_ID, "SOLTEAM Rugpull Checker started.");
  }
});

// Graceful shutdown
process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
