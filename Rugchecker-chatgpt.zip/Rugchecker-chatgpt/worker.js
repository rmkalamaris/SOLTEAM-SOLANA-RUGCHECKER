const { runChecksCommand } = require("./commands");

let myQueue = null;
let workerEnabled = false;

function createWorkerQueue() {
  // Skip queue setup if Redis is not properly configured or is Upstash (incompatible with BullMQ)
  if (!process.env.REDIS_URL || process.env.REDIS_URL.includes('upstash.io')) {
    console.log("⚠️  Background queue disabled - Redis not configured or incompatible with BullMQ");
    console.log("   Bot will work without background jobs. For production, use a standard Redis instance.");
    return;
  }

  try {
    const { Queue, Worker } = require("bullmq");
    const IORedis = require("ioredis");
    
    const connection = new IORedis(process.env.REDIS_URL);
    const queueName = "rugchecks";
    myQueue = new Queue(queueName, { connection });

    // Start worker
    const worker = new Worker(queueName, async (job) => {
      const { mint, exhaustive } = job.data;
      const r = await runChecksCommand(mint, { exhaustive });
      return r;
    }, { connection });

    worker.on("completed", (job, result) => {
      console.log("Job completed:", job.id, result.score);
    });
    worker.on("failed", (job, err) => {
      console.error("Job failed:", job.id, err.message);
    });

    workerEnabled = true;
    console.log("✅ Worker queue created and enabled");
  } catch (error) {
    console.error("❌ Failed to create worker queue:", error.message);
    console.log("   Bot will continue without background jobs");
  }
}

module.exports = { createWorkerQueue, myQueue };
