import express from 'express';
import { Env } from './config/env';

export function startHttpServer() {
  const app = express();
  app.get('/', (_req, res) => res.send('Bot is running'));
  app.get('/health', (_req, res) => res.json({ ok: true }));
  const port = Env.PORT || 3000;
  app.listen(port, () => {
    console.log(`HTTP server listening on :${port}`);
  });
}
