# Solana Rugscanner Bot

## Quick Start (Local)
```
npm ci
npm run dev
```

## Deploy to Render (Node Worker - No Docker)
1. Create a **Background Worker** service.
2. **Root Directory**: leave blank or set to `.` (do **not** set to `/src`).
3. **Build Command**: `npm ci && npm run build`
4. **Start Command**: `node dist/index.js`  (or `npm run start`)
5. Set your Environment Variables (Telegram token, RPC, etc.).
6. Save & deploy.

> If Render tries to run `yarn` and can't find `package.json`, it's because the **Root Directory** is wrong. Fix it to the repo root.

## Deploy to Render (Docker Worker - Optional)
If you prefer Docker, use the included `Dockerfile` and create a **Background Worker (Docker)**.
No build/start commands needed—Render will use the Dockerfile.

