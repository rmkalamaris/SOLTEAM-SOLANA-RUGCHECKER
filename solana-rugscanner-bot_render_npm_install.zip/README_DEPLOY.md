# Render Deploy Notes

If you see `npm ci` errors, it's because `npm ci` requires a package-lock.json.
This project uses `npm install` in CI and Docker to avoid that requirement.

**Render Web Service Settings**
- Root Directory: `.`
- Build Command: `npm install && npm run build`
- Start Command: `node dist/index.js`
- Environment variables: TELEGRAM_BOT_TOKEN, TELEGRAM_ADMIN_CHAT_ID, SOLANA_RPC_HTTP, etc.
