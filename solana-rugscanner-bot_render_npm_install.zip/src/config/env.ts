import 'dotenv/config';

function req(name: string): string {
  const v = process.env[name];
  if (!v || !v.trim()) throw new Error(`Missing required env var: ${name}`);
  return v.trim();
}

export const Env = {
  TELEGRAM_BOT_TOKEN: req('TELEGRAM_BOT_TOKEN'),
  TELEGRAM_ADMIN_CHAT_ID: req('TELEGRAM_ADMIN_CHAT_ID'),
  SOLANA_RPC_HTTP: req('SOLANA_RPC_HTTP'),

  HELIUS_API_KEY: process.env.HELIUS_API_KEY || '',
  KNOWN_USD1_MINTS: (process.env.KNOWN_USD1_MINTS || '').trim(),

  PORT: Number(process.env.PORT || 3000),
  NODE_ENV: (process.env.NODE_ENV || 'production') as 'development' | 'production' | 'test',
};
