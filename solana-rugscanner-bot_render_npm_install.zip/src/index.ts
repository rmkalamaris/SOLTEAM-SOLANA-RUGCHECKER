import { Telegraf } from 'telegraf';
import { Env } from './config/env';

const bot = new Telegraf(Env.TELEGRAM_BOT_TOKEN);

bot.start(async (ctx) => {
  await ctx.reply(
    `👋 Hey! I’m online.\nSend /scan <mint> to analyze a Solana token.`
  );
});

bot.command('scan', async (ctx) => {
  const input = ctx.message?.text?.split(/\s+/).slice(1).join(' ').trim();
  if (!input) return ctx.reply('Usage: /scan <mint_or_url>');
  await ctx.reply(`🔎 Scanning: ${input}\n(placeholder — scanner wiring next)`);
});

bot.catch((err) => console.error('Bot error:', err));

async function main() {
  console.log('Starting bot…');
  const me = await bot.telegram.getMe();
  console.log('Authenticated as @' + me.username);
  await bot.launch();
  console.log('Bot is up ✅');
  process.once('SIGINT', () => bot.stop('SIGINT'));
  process.once('SIGTERM', () => bot.stop('SIGTERM'));
}

main().catch((e) => {
  console.error('Fatal startup error:', e);
  process.exit(1);
});


// Start minimal HTTP server for Render Web Service health checks
import { startHttpServer } from './server';
startHttpServer();
