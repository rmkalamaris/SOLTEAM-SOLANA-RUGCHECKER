const axios = require("axios");
const { Connection, PublicKey } = require("@solana/web3.js");

// Cache for market data to avoid rate limiting
const marketDataCache = new Map();
const CACHE_TTL = 2 * 60 * 1000; // 2 minutes for market data

// Get comprehensive market data from DexScreener
async function getDexScreenerData(tokenAddress) {
  const cacheKey = `dexscreener_${tokenAddress}`;
  const cached = marketDataCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }

  try {
    const response = await axios.get(`https://api.dexscreener.com/tokens/v1/solana/${tokenAddress}`, {
      timeout: 5000
    });

    const data = response.data;
    const pairs = data.pairs || [];
    
    if (pairs.length === 0) {
      // Fallback to alternative DexScreener endpoints
      console.log('No pairs found, trying fallback endpoints...');
      return await getDexScreenerDataFallback(tokenAddress);
    }

    // Find the most liquid pair (usually the main trading pair)
    const mainPair = pairs.reduce((prev, current) => 
      (prev.liquidity?.usd > current.liquidity?.usd) ? prev : current
    );

    const marketData = {
      name: mainPair.baseToken?.name || null,
      symbol: mainPair.baseToken?.symbol || null,
      priceUsd: parseFloat(mainPair.priceUsd) || 0,
      priceNative: parseFloat(mainPair.priceNative) || 0,
      marketCap: mainPair.marketCap || 0,
      fdv: mainPair.fdv || 0,
      liquidity: {
        usd: mainPair.liquidity?.usd || 0,
        base: mainPair.liquidity?.base || 0,
        quote: mainPair.liquidity?.quote || 0
      },
      volume: {
        h24: mainPair.volume?.h24 || 0,
        h6: mainPair.volume?.h6 || 0,
        h1: mainPair.volume?.h1 || 0
      },
      txns: {
        h24: {
          buys: mainPair.txns?.h24?.buys || 0,
          sells: mainPair.txns?.h24?.sells || 0,
          total: (mainPair.txns?.h24?.buys || 0) + (mainPair.txns?.h24?.sells || 0)
        },
        h6: {
          buys: mainPair.txns?.h6?.buys || 0,
          sells: mainPair.txns?.h6?.sells || 0,
          total: (mainPair.txns?.h6?.buys || 0) + (mainPair.txns?.h6?.sells || 0)
        }
      },
      priceChange: {
        h24: mainPair.priceChange?.h24 || 0,
        h6: mainPair.priceChange?.h6 || 0,
        h1: mainPair.priceChange?.h1 || 0
      },
      pairAddress: mainPair.pairAddress || null,
      dexId: mainPair.dexId || null,
      url: mainPair.url || null,
      pairCreatedAt: mainPair.pairCreatedAt || null,
      website: mainPair.info?.websites?.[0]?.url || null,
      twitter: mainPair.info?.socials?.find(s => s.type === 'twitter')?.url || null,
      telegram: mainPair.info?.socials?.find(s => s.type === 'telegram')?.url || null,
      athTimestamp: null, // Not available in DexScreener API
      athPrice: null, // We'll calculate this from other sources if needed
      makers: null, // Not directly available, will need to calculate from transaction data
      age: null // Will calculate from pair creation time
    };

    // Calculate token age if creation time is available
    if (marketData.pairCreatedAt) {
      // Handle both seconds and milliseconds timestamps
      const pairCreatedAtMs = marketData.pairCreatedAt > 1e12 ? marketData.pairCreatedAt : marketData.pairCreatedAt * 1000;
      const ageInHours = (Date.now() - pairCreatedAtMs) / 3600000;
      marketData.age = {
        hours: Math.floor(ageInHours),
        days: Math.floor(ageInHours / 24),
        formatted: formatAge(ageInHours)
      };
    }

    // Cache the result
    marketDataCache.set(cacheKey, { data: marketData, timestamp: Date.now() });
    return marketData;

  } catch (error) {
    console.error('DexScreener API error:', error.message);
    // Fallback to alternative endpoints
    console.log('Main DexScreener failed, trying fallback endpoints...');
    return await getDexScreenerDataFallback(tokenAddress);
  }
}

// Fallback function with alternative endpoints and Jupiter integration
async function getDexScreenerDataFallback(tokenAddress) {
  try {
    // Try alternative DexScreener endpoint
    console.log('Trying alternative DexScreener endpoint...');
    const response = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${tokenAddress}`, {
      timeout: 5000
    });
    
    const pairs = response.data?.pairs || [];
    if (pairs.length > 0) {
      const mainPair = pairs[0]; // Take first available pair
      return {
        name: mainPair.baseToken?.name || null,
        symbol: mainPair.baseToken?.symbol || null,
        priceUsd: parseFloat(mainPair.priceUsd) || 0,
        priceNative: parseFloat(mainPair.priceNative) || 0,
        marketCap: mainPair.marketCap || 0,
        fdv: mainPair.fdv || 0,
        liquidity: {
          usd: mainPair.liquidity?.usd || 0,
          base: mainPair.liquidity?.base || 0,
          quote: mainPair.liquidity?.quote || 0
        },
        volume: {
          h24: mainPair.volume?.h24 || 0,
          h6: mainPair.volume?.h6 || 0,
          h1: mainPair.volume?.h1 || 0
        },
        txns: {
          h24: {
            buys: mainPair.txns?.h24?.buys || 0,
            sells: mainPair.txns?.h24?.sells || 0,
            total: (mainPair.txns?.h24?.buys || 0) + (mainPair.txns?.h24?.sells || 0)
          }
        },
        pairAddress: mainPair.pairAddress || null,
        dexId: mainPair.dexId || null,
        url: mainPair.url || null,
        pairCreatedAt: mainPair.pairCreatedAt || null
      };
    }
  } catch (error) {
    console.log('Alternative DexScreener also failed:', error.message);
  }

  // Final fallback: Get basic price from Jupiter
  try {
    console.log('Falling back to Jupiter for basic price data...');
    const jupiterData = await getJupiterPriceData(tokenAddress);
    if (jupiterData && jupiterData.price) {
      return {
        name: null,
        symbol: null,
        priceUsd: jupiterData.price,
        priceNative: 0,
        marketCap: 0,
        fdv: 0,
        liquidity: { usd: 0, base: 0, quote: 0 },
        volume: { h24: 0, h6: 0, h1: 0 },
        txns: { h24: { buys: 0, sells: 0, total: 0 } },
        pairAddress: null,
        dexId: null,
        url: null,
        pairCreatedAt: null
      };
    }
  } catch (error) {
    console.log('Jupiter fallback also failed:', error.message);
  }

  // Return minimal data structure to prevent N/A everywhere
  return {
    name: null,
    symbol: null,
    priceUsd: 0,
    priceNative: 0,
    marketCap: 0,
    fdv: 0,
    liquidity: { usd: 0, base: 0, quote: 0 },
    volume: { h24: 0, h6: 0, h1: 0 },
    txns: { h24: { buys: 0, sells: 0, total: 0 } },
    pairAddress: null,
    dexId: null,
    url: null,
    pairCreatedAt: null
  };
}

// Get additional token price data from Jupiter
async function getJupiterPriceData(tokenAddress) {
  try {
    const response = await axios.get(`https://api.jup.ag/price/v2?ids=${tokenAddress}`, {
      timeout: 3000
    });

    const data = response.data?.data;
    if (!data || !data[tokenAddress]) {
      return null;
    }

    const tokenData = data[tokenAddress];
    return {
      id: tokenData.id,
      type: tokenData.type,
      price: tokenData.price || 0,
      extraInfo: tokenData.extraInfo || null
    };

  } catch (error) {
    console.error('Jupiter Price API error:', error.message);
    return null;
  }
}

// Get comprehensive token info including social links
async function getTokenSocialData(tokenAddress) {
  const cacheKey = `social_${tokenAddress}`;
  const cached = marketDataCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL * 2) { // Longer cache for social data
    return cached.data;
  }

  try {
    // Try to get social data from DexScreener first
    const dexData = await getDexScreenerData(tokenAddress);
    if (dexData && (dexData.website || dexData.twitter)) {
      const socialData = {
        website: dexData.website,
        twitter: dexData.twitter,
        telegram: dexData.telegram,
        dexScreenerUrl: dexData.url
      };
      
      marketDataCache.set(cacheKey, { data: socialData, timestamp: Date.now() });
      return socialData;
    }

    // Fallback: Try to get from token metadata
    return {
      website: null,
      twitter: null,
      telegram: null,
      dexScreenerUrl: null
    };

  } catch (error) {
    console.error('Social data fetch error:', error.message);
    return null;
  }
}

// Get token creation and technical details
async function getTokenTechnicalData(tokenAddress, connection) {
  try {
    const mintPub = new PublicKey(tokenAddress);
    
    // Get mint account info
    const mintAccount = await connection.getParsedAccountInfo(mintPub);
    if (!mintAccount.value?.data?.parsed) {
      return null;
    }

    const mintInfo = mintAccount.value.data.parsed.info;
    
    // Get creation details by checking earliest transactions
    let creationTime = null;
    let creatorAddress = null;
    
    try {
      const signatures = await connection.getSignaturesForAddress(mintPub, { limit: 1000 });
      if (signatures.length > 0) {
        // Get the earliest signature (token creation)
        const earliestSig = signatures[signatures.length - 1];
        creationTime = earliestSig.blockTime;
        
        // Get transaction details to find creator
        const txDetails = await connection.getParsedTransaction(earliestSig.signature);
        if (txDetails?.transaction?.message?.instructions?.[0]) {
          creatorAddress = txDetails.transaction.message.accountKeys?.[0]?.pubkey?.toString();
        }
      }
    } catch (e) {
      console.error('Error getting creation data:', e.message);
    }

    // Determine token program type
    const owner = mintAccount.value.owner;
    const ownerStr = owner?.toString?.() || owner;
    let tokenProgram = 'Unknown';
    if (ownerStr === 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA') {
      tokenProgram = 'SPL Token v1';
    } else if (ownerStr === 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb') {
      tokenProgram = 'Token-2022';
    }

    return {
      tokenProgram,
      supply: mintInfo.supply,
      decimals: mintInfo.decimals,
      mintAuthority: mintInfo.mintAuthority,
      freezeAuthority: mintInfo.freezeAuthority,
      creationTime,
      creatorAddress,
      age: creationTime ? {
        timestamp: creationTime,
        hours: Math.floor((Date.now() / 1000 - creationTime) / 3600),
        days: Math.floor((Date.now() / 1000 - creationTime) / 86400),
        formatted: formatAge((Date.now() / 1000 - creationTime) / 3600)
      } : null
    };

  } catch (error) {
    console.error('Technical data fetch error:', error.message);
    return null;
  }
}

// Helper function to format age
function formatAge(ageInHours) {
  if (ageInHours < 1) {
    return `${Math.floor(ageInHours * 60)} minutes`;
  } else if (ageInHours < 24) {
    return `${Math.floor(ageInHours)} hours`;
  } else if (ageInHours < 24 * 7) {
    return `${Math.floor(ageInHours / 24)} days`;
  } else if (ageInHours < 24 * 30) {
    return `${Math.floor(ageInHours / (24 * 7))} weeks`;
  } else {
    return `${Math.floor(ageInHours / (24 * 30))} months`;
  }
}

// Format number with appropriate suffixes
function formatNumber(num) {
  if (!num || num === 0) return '0';
  
  const absNum = Math.abs(num);
  if (absNum >= 1e9) {
    return `${(num / 1e9).toFixed(2)}B`;
  } else if (absNum >= 1e6) {
    return `${(num / 1e6).toFixed(2)}M`;
  } else if (absNum >= 1e3) {
    return `${(num / 1e3).toFixed(2)}K`;
  }
  return num.toFixed(2);
}

// Format USD values
function formatUSD(amount) {
  if (!amount || amount === 0) return '$0';
  return `$${formatNumber(amount)}`;
}

module.exports = {
  getDexScreenerData,
  getJupiterPriceData,
  getTokenSocialData,
  getTokenTechnicalData,
  formatNumber,
  formatUSD
};