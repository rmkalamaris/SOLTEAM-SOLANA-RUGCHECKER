const { Connection, PublicKey } = require("@solana/web3.js");
const axios = require("axios");
const Decimal = require("decimal.js");
const { parseProgramLogs } = require("./logs");
const { simulateSwapRoute } = require("./dex");
const { loadHolderStats, getPoolInfoForToken } = require("./onchainHelpers");

const connection = new Connection(process.env.RPC_URL || "https://api.mainnet-beta.solana.com", "confirmed");
const HELIUS_KEY = process.env.HELIUS_API_KEY || null;

async function doCoreChecks(mintAddress) {
  const res = {};
  const mintPub = new PublicKey(mintAddress);

  // 1) Mint account info (mintAuthority, freezeAuthority, supply)
  const mintAcc = await connection.getParsedAccountInfo(mintPub);
  if (!mintAcc.value) throw new Error("Mint account not found or invalid address");
  const parsed = mintAcc.value.data?.parsed;
  if (!parsed || parsed.type !== "mint") throw new Error("Address is not an SPL mint account");
  const info = parsed.info || {};
  res.mintAuthority = info.mintAuthority || null;
  res.freezeAuthority = info.freezeAuthority || null;
  res.supply = info.supply || null;
  res.decimals = info.decimals || 0;

  // Fetch token metadata
  res.metadata = await getTokenMetadata(mintAddress);

  // 2) Recent authority changes and recent mints via Helius or getSignaturesForAddress
  res.recentMintEvents = await _getRecentMintEvents(mintPub);

  // 3) Top holders concentration
  const holders = await connection.getTokenLargestAccounts(mintPub); // returns token account pubkeys + amount
  const top = holders.value || [];
  // Map token accounts to owners and totals
  res.topHolders = await loadHolderStats(connection, top);
  res.topHoldersPercent = computeTopHolderPercent(res.topHolders, res.supply);

  return res;
}

async function doExhaustiveChecks(mintAddress, core = {}) {
  const res = { ...core };
  const mintPub = new PublicKey(mintAddress);

  console.log('🔍 Starting comprehensive token analysis...');

  // Import the new market data and analytics modules
  const { getDexScreenerData, getJupiterPriceData, getTokenSocialData, getTokenTechnicalData } = require('./marketData');
  const { getHolderAnalysis, getLiquidityAnalysis, performTradingAnalysis } = require('./advancedAnalytics');

  // 1. Market Data from DexScreener
  console.log('📊 Fetching market data...');
  res.marketData = await getDexScreenerData(mintAddress);
  
  // 2. Additional price data from Jupiter
  res.jupiterData = await getJupiterPriceData(mintAddress);
  
  // 3. Social media and website links
  res.socialData = await getTokenSocialData(mintAddress);
  
  // 4. Technical token details
  res.technicalData = await getTokenTechnicalData(mintAddress, connection);
  
  // 5. Advanced holder analysis
  console.log('👥 Analyzing holders...');
  const topHolders = res.topHolders || []; // From core checks
  res.holderAnalysis = await getHolderAnalysis(connection, mintAddress, topHolders, HELIUS_KEY);
  
  // 6. Liquidity analysis
  console.log('💧 Analyzing liquidity...');
  res.liquidityAnalysis = await getLiquidityAnalysis(connection, mintAddress);
  
  // 7. Trading and honeypot analysis
  console.log('🍯 Performing trading analysis...');
  res.tradingAnalysis = await performTradingAnalysis(mintAddress);

  // Original checks (enhanced)
  // Liquidity: try to find pools on common AMMs
  res.pools = await getPoolInfoForToken(connection, mintPub);
  // Analyze liquidity concentration
  res.liquidityRisk = analyzePools(res.pools);

  // Program log analysis (calls like setAuthority, withdraw, setFee)
  res.programLogs = await parseProgramLogs(mintPub, { heliusKey: HELIUS_KEY, connection });

  // Enhanced honeypot simulation
  try {
    res.honeypotCheck = await honeypotSimulation(mintAddress);
  } catch (e) {
    res.honeypotCheck = { error: e.message };
  }

  // Check program upgrade authority if token uses custom program (advanced)
  res.programUpgradeInfo = await checkProgramUpgradeInfoIfAny(mintPub);

  console.log('✅ Comprehensive analysis complete');
  return res;
}

/* helper implementations */

async function _getRecentMintEvents(mintPub) {
  // Use Helius if available for event logs; fallback to getSignaturesForAddress and parse
  try {
    if (HELIUS_KEY) {
      const url = `https://api.helius.xyz/v0/addresses/${mintPub.toBase58()}/transactions?api-key=${HELIUS_KEY}&type=parsed`;
      const r = await axios.get(url, { timeout: 10000 });
      const txs = r.data || [];
      // scan for MintTo instructions
      const mints = [];
      for (const tx of txs) {
        if (tx?.signature && tx?.parsedTransactions) {
          // heuristic: search instructions
          const logs = JSON.stringify(tx);
          if (logs.match(/MintTo|mintTo|mint_to/i)) {
            mints.push({ signature: tx.signature, raw: tx });
          }
        }
      }
      return { source: "helius", mints: mints.slice(0, 25) };
    } else {
      // fallback
      const sigs = await connection.getSignaturesForAddress(mintPub, { limit: 50 });
      const results = [];
      for (const s of sigs) {
        const tx = await connection.getParsedTransaction(s.signature);
        if (!tx) continue;
        const msg = JSON.stringify(tx);
        if (msg.match(/MintTo|mintTo|mint_to/i)) {
          results.push({ signature: s.signature, slot: s.slot });
        }
      }
      return { source: "rpc", mints: results };
    }
  } catch (e) {
    return { error: e.message };
  }
}

function computeTopHolderPercent(topHolders, totalSupply) {
  // topHolders: [{owner, amountRaw, decimals}] amounts are raw token amounts as strings
  // totalSupply: the actual total supply of the token from mint account
  try {
    if (!topHolders || topHolders.length === 0 || !totalSupply) {
      return { top1: 0, top5: 0, top10: 0 };
    }
    
    const supply = new Decimal(totalSupply);
    if (supply.eq(0)) return { top1: 0, top5: 0, top10: 0 };

    // Aggregate amounts by owner (in case same owner has multiple token accounts)
    const ownerAmounts = new Map();
    for (const holder of topHolders) {
      const amount = new Decimal(holder.amountRaw);
      const currentAmount = ownerAmounts.get(holder.owner) || new Decimal(0);
      ownerAmounts.set(holder.owner, currentAmount.add(amount));
    }

    // Sort by amount descending
    const sortedOwners = Array.from(ownerAmounts.entries())
      .sort(([,a], [,b]) => b.sub(a).toNumber());

    // Calculate percentages
    const top1 = sortedOwners.length > 0 ? 
      sortedOwners[0][1].div(supply).mul(100).toNumber() : 0;
    
    const top5Amount = sortedOwners.slice(0, 5)
      .reduce((sum, [,amount]) => sum.add(amount), new Decimal(0));
    const top5 = top5Amount.div(supply).mul(100).toNumber();
    
    const top10Amount = sortedOwners.slice(0, 10)
      .reduce((sum, [,amount]) => sum.add(amount), new Decimal(0));
    const top10 = top10Amount.div(supply).mul(100).toNumber();
    
    return { top1, top5, top10 };
  } catch (e) {
    console.error('Error computing holder percentages:', e);
    return { top1: 0, top5: 0, top10: 0 };
  }
}

async function honeypotSimulation(mintAddress) {
  // By default simulate route price (no real trade). If user enables microtrade & keys present then can actually do microtrade.
  // Use a DEX aggregator API to get route (e.g., Jupiter API) — here we simulate via public Jupiter quote endpoints.
  try {
    const sim = await simulateSwapRoute(mintAddress);
    return sim;
  } catch (e) {
    return { error: e.message };
  }
}

async function checkProgramUpgradeInfoIfAny(mintPub) {
  // Token mints normally use SPL Token program; custom program usage needs extra parsing.
  // Placeholder: returns empty unless custom program inspected
  return {};
}

function analyzePools(pools) {
  // Simple heuristics: pool count, largest LP contributor, locked status
  try {
    const summary = { poolCount: pools.length, risks: [] };
    for (const p of pools) {
      if (!p.locked && p.liquidityOwnerSingle && p.liquidityOwnerSingle.percent > 60) {
        summary.risks.push(`Pool ${p.id} has >60% liquidity from single wallet ${p.liquidityOwnerSingle.owner}`);
      }
      if (!p.locked && p.ownerIsDev) {
        summary.risks.push(`Pool ${p.id} authority is a dev wallet and not locked`);
      }
    }
    return summary;
  } catch (e) {
    return { error: e.message };
  }
}

// Simple in-memory cache for metadata to reduce API calls
const metadataCache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

// Get token metadata from various sources with caching
async function getTokenMetadata(mintAddress) {
  // Check cache first
  const cacheKey = `metadata_${mintAddress}`;
  const cached = metadataCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }

  const metadata = {
    name: null,
    symbol: null,
    logoURI: null,
    description: null
  };

  try {
    // Try Jupiter tokens API first (more reliable than price endpoint)
    const response = await axios.get(`https://tokens.jup.ag/token/${mintAddress}`, {
      timeout: 3000
    });
    const tokenData = response.data;
    if (tokenData) {
      metadata.name = tokenData.name;
      metadata.symbol = tokenData.symbol;
      metadata.logoURI = tokenData.logoURI;
      // Cache and return early if found
      metadataCache.set(cacheKey, { data: metadata, timestamp: Date.now() });
      return metadata;
    }
  } catch (e) {
    // Continue to other methods
  }

  try {
    // Try Helius metadata if available
    if (HELIUS_KEY) {
      const response = await axios.post(`https://api.helius.xyz/v0/token-metadata?api-key=${HELIUS_KEY}`, {
        mintAccounts: [mintAddress]
      }, { timeout: 3000 });
      
      const tokenMeta = response.data?.[0];
      if (tokenMeta?.onChainMetadata?.metadata?.data) {
        const data = tokenMeta.onChainMetadata.metadata.data;
        metadata.name = data.name || metadata.name;
        metadata.symbol = data.symbol || metadata.symbol;
        metadata.description = data.description || metadata.description;
        metadata.logoURI = data.image || metadata.logoURI;
      }
    }
  } catch (e) {
    // Helius failed, continue
  }

  // Cache result even if incomplete
  metadataCache.set(cacheKey, { data: metadata, timestamp: Date.now() });
  return metadata;
}

module.exports = { doCoreChecks, doExhaustiveChecks };
