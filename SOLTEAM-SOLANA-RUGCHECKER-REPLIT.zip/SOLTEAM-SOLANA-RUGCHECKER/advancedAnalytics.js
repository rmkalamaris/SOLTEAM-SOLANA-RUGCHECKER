const axios = require("axios");
const { Connection, PublicKey } = require("@solana/web3.js");
const Decimal = require("decimal.js");

// Get comprehensive holder analysis
async function getHolderAnalysis(connection, mintAddress, topHolders, heliusKey) {
  try {
    const analysis = {
      topHoldersBreakdown: [],
      suspiciousPatterns: [],
      devWallet: null,
      snipersDetected: 0,
      clusterAnalysis: null,
      freshWallets: 0,
      whaleActivity: []
    };

    // Analyze top holders (get top 20 for better analysis)
    const mintPub = new PublicKey(mintAddress);
    const largestAccounts = await connection.getTokenLargestAccounts(mintPub);
    const topAccounts = largestAccounts.value.slice(0, 20);

    // Get detailed holder information
    for (let i = 0; i < Math.min(10, topAccounts.length); i++) {
      const account = topAccounts[i];
      try {
        const accountInfo = await connection.getParsedAccountInfo(new PublicKey(account.address));
        const owner = accountInfo.value?.data?.parsed?.info?.owner;
        
        if (owner) {
          // Get wallet creation time and transaction history
          const walletAnalysis = await analyzeWalletBehavior(connection, owner, mintAddress);
          
          analysis.topHoldersBreakdown.push({
            rank: i + 1,
            address: owner,
            tokenAmount: account.amount,
            percentage: null, // Will calculate later with total supply
            walletAge: walletAnalysis.walletAge,
            firstSeenToken: walletAnalysis.firstSeenToken,
            totalTransactions: walletAnalysis.totalTransactions,
            suspiciousFlags: walletAnalysis.suspiciousFlags
          });

          // Check for suspicious patterns
          if (walletAnalysis.suspiciousFlags.length > 0) {
            analysis.suspiciousPatterns.push({
              wallet: owner,
              rank: i + 1,
              flags: walletAnalysis.suspiciousFlags
            });
          }

          // Check for fresh wallets (created recently)
          if (walletAnalysis.walletAge && walletAnalysis.walletAge < 24) { // Less than 24 hours
            analysis.freshWallets++;
          }

          // Identify potential dev wallet (large holder with early activity)
          if (i === 0 && walletAnalysis.firstSeenToken && walletAnalysis.firstSeenToken < 3600) { // Top holder who got tokens within first hour
            analysis.devWallet = {
              address: owner,
              evidence: ['largest_holder', 'early_acquisition'],
              tokenAmount: account.amount
            };
          }
        }
      } catch (e) {
        console.error(`Error analyzing holder ${i}:`, e.message);
      }
    }

    // Detect cluster patterns (wallets funded from same source)
    if (heliusKey && analysis.topHoldersBreakdown.length > 3) {
      analysis.clusterAnalysis = await detectWalletClusters(analysis.topHoldersBreakdown, heliusKey);
    }

    return analysis;

  } catch (error) {
    console.error('Holder analysis error:', error.message);
    return null;
  }
}

// Analyze individual wallet behavior
async function analyzeWalletBehavior(connection, walletAddress, tokenMint) {
  const analysis = {
    walletAge: null,
    firstSeenToken: null,
    totalTransactions: 0,
    suspiciousFlags: []
  };

  try {
    // Get wallet's transaction history
    const signatures = await connection.getSignaturesForAddress(new PublicKey(walletAddress), { limit: 100 });
    analysis.totalTransactions = signatures.length;

    if (signatures.length === 0) {
      analysis.suspiciousFlags.push('no_transaction_history');
      return analysis;
    }

    // Calculate wallet age (time since first transaction)
    const oldestTx = signatures[signatures.length - 1];
    if (oldestTx.blockTime) {
      analysis.walletAge = (Date.now() / 1000 - oldestTx.blockTime) / 3600; // Hours
    }

    // Find first interaction with this token
    let tokenTxCount = 0;
    for (const sig of signatures.slice(-50)) { // Check last 50 transactions
      try {
        const txDetails = await connection.getParsedTransaction(sig.signature);
        if (txDetails && JSON.stringify(txDetails).includes(tokenMint)) {
          tokenTxCount++;
          if (!analysis.firstSeenToken && sig.blockTime) {
            // Calculate time since token creation for this wallet's first interaction
            analysis.firstSeenToken = (Date.now() / 1000 - sig.blockTime) / 3600;
          }
        }
      } catch (e) {
        // Skip failed transactions
      }
    }

    // Analyze suspicious patterns
    if (analysis.walletAge && analysis.walletAge < 1) { // Very new wallet
      analysis.suspiciousFlags.push('very_new_wallet');
    }

    if (tokenTxCount === analysis.totalTransactions && tokenTxCount < 5) {
      analysis.suspiciousFlags.push('single_token_activity'); // Only interacted with this token
    }

    if (analysis.totalTransactions < 3) {
      analysis.suspiciousFlags.push('low_activity'); // Very low transaction count
    }

    // Check for burst transactions (multiple transactions in short time)
    if (signatures.length >= 5) {
      const recentTxs = signatures.slice(0, 5);
      const timeSpan = recentTxs[0].blockTime - recentTxs[4].blockTime;
      if (timeSpan < 60) { // 5 transactions in 1 minute
        analysis.suspiciousFlags.push('burst_transactions');
      }
    }

  } catch (error) {
    console.error('Wallet behavior analysis error:', error.message);
    analysis.suspiciousFlags.push('analysis_failed');
  }

  return analysis;
}

// Detect wallet clusters using Helius Enhanced Transactions
async function detectWalletClusters(topHolders, heliusKey) {
  try {
    const clusters = [];
    const walletFundingSources = new Map();

    // Analyze funding patterns for top holders
    for (const holder of topHolders.slice(0, 5)) { // Analyze top 5 holders
      try {
        const response = await axios.get(
          `https://api.helius.xyz/v0/addresses/${holder.address}/transactions?api-key=${heliusKey}&limit=10`,
          { timeout: 5000 }
        );

        const transactions = response.data || [];
        
        // Look for SOL transfers that funded this wallet
        for (const tx of transactions) {
          if (tx.type === 'TRANSFER' && tx.token === 'SOL') {
            const fromAddress = tx.accounts?.[0]; // Simplified - actual parsing would be more complex
            if (fromAddress && fromAddress !== holder.address) {
              if (!walletFundingSources.has(fromAddress)) {
                walletFundingSources.set(fromAddress, []);
              }
              walletFundingSources.get(fromAddress).push(holder.address);
            }
          }
        }
      } catch (e) {
        console.error(`Cluster analysis error for ${holder.address}:`, e.message);
      }
    }

    // Identify clusters (same funding source for multiple wallets)
    for (const [source, funded] of walletFundingSources.entries()) {
      if (funded.length >= 2) {
        clusters.push({
          fundingSource: source,
          fundedWallets: funded,
          suspicionLevel: funded.length >= 3 ? 'high' : 'medium'
        });
      }
    }

    return {
      clustersFound: clusters.length,
      clusters: clusters,
      riskLevel: clusters.length > 0 ? 'elevated' : 'normal'
    };

  } catch (error) {
    console.error('Cluster detection error:', error.message);
    return null;
  }
}

// Get liquidity pool analysis
async function getLiquidityAnalysis(connection, tokenMint) {
  try {
    const analysis = {
      pools: [],
      totalLiquidity: 0,
      isLiquidityLocked: null,
      liquidityProviders: [],
      poolAge: null,
      riskFactors: []
    };

    // This is a simplified implementation
    // In a production environment, you would need to:
    // 1. Query specific DEX programs (Raydium, Orca, etc.)
    // 2. Parse pool accounts and LP token distributions
    // 3. Check for liquidity locks and vesting schedules
    
    // For now, we'll return a basic structure that can be expanded
    analysis.riskFactors.push('liquidity_analysis_limited');
    
    return analysis;

  } catch (error) {
    console.error('Liquidity analysis error:', error.message);
    return null;
  }
}

// Enhanced honeypot and trading simulation
async function performTradingAnalysis(tokenMint) {
  try {
    const analysis = {
      honeypotRisk: 'unknown',
      canSell: null,
      sellTax: null,
      buyTax: null,
      tradingRestrictions: [],
      liquidityIssues: []
    };

    // Try to simulate a small swap using Jupiter
    try {
      const quoteResponse = await axios.get(
        `https://quote-api.jup.ag/v6/quote?inputMint=So11111111111111111111111111111111111111112&outputMint=${tokenMint}&amount=1000000`, // 0.001 SOL
        { timeout: 5000 }
      );

      if (quoteResponse.data) {
        analysis.canSell = true;
        analysis.honeypotRisk = 'low';
      }

      // Try reverse quote to check if selling is possible
      const sellResponse = await axios.get(
        `https://quote-api.jup.ag/v6/quote?inputMint=${tokenMint}&outputMint=So11111111111111111111111111111111111111112&amount=1000`, // Small amount of token
        { timeout: 5000 }
      );

      if (!sellResponse.data) {
        analysis.canSell = false;
        analysis.honeypotRisk = 'high';
        analysis.tradingRestrictions.push('sell_blocked');
      }

    } catch (error) {
      analysis.honeypotRisk = 'medium';
      analysis.tradingRestrictions.push('routing_issues');
    }

    return analysis;

  } catch (error) {
    console.error('Trading analysis error:', error.message);
    return null;
  }
}

module.exports = {
  getHolderAnalysis,
  analyzeWalletBehavior,
  detectWalletClusters,
  getLiquidityAnalysis,
  performTradingAnalysis
};