function computeScore(data) {
  let score = 0;
  // Critical checks
  if (data.mintAuthority) score += 50;
  if (data.freezeAuthority) score += 30;
  if (data.recentMintEvents && data.recentMintEvents.mints && data.recentMintEvents.mints.length > 0) score += 30;
  if (data.topHoldersPercent && data.topHoldersPercent.top1 && data.topHoldersPercent.top1 > 40) score += 20;
  // liquidity heuristics
  if (data.liquidityRisk && data.liquidityRisk.risks && data.liquidityRisk.risks.length > 0) score += 25;
  // logs
  if (data.programLogs && data.programLogs.suspicious && data.programLogs.suspicious.length > 0) score += 30;
  // honeypot simulation
  if (data.honeypotCheck && data.honeypotCheck.error) score += 40;
  if (data.honeypotCheck && data.honeypotCheck.simulated === true && data.honeypotCheck.quotesSummary && data.honeypotCheck.quotesSummary.length === 0) score += 10;

  // clamp
  if (score > 100) score = 100;
  return score;
}

function formatSummary(mint, data, score) {
  let md = `*SOLTEAM Rugpull Quick Scan*\n\n`;
  
  // Token Information Section
  md += `📊 *TOKEN INFORMATION*\n`;
  md += `• Address: \`${mint}\`\n`;
  
  // Show token name/symbol if available
  if (data.metadata && (data.metadata.name || data.metadata.symbol)) {
    const name = data.metadata.name || 'Unknown';
    const symbol = data.metadata.symbol || 'N/A';
    md += `• Name: ${name} (${symbol})\n`;
  }
  
  // Supply and decimals info
  if (data.supply) {
    const supplyFormatted = formatTokenAmount(data.supply, data.decimals || 0);
    md += `• Total Supply: ${supplyFormatted}\n`;
  }
  md += `• Decimals: ${data.decimals || 0}\n`;
  
  // Top holder breakdown
  if (data.topHolders && data.topHolders.length > 0) {
    const top1Percent = data.topHoldersPercent?.top1 || 0;
    const top5Percent = data.topHoldersPercent?.top5 || 0;
    md += `• Top 1 Holder: ${top1Percent.toFixed(2)}%\n`;
    
    if (data.topHolders.length > 1) {
      md += `• Top 5 Holders: ${top5Percent.toFixed(2)}%\n`;
    }
  }
  
  md += `\n🔍 *RISK ANALYSIS*\n`;
  md += `• Overall Risk Score: *${score}/100*\n\n`;
  
  // Security checks
  md += `• Mint Authority: ${data.mintAuthority ? `⚠️ \`${data.mintAuthority}\`` : "✅ Revoked"}\n`;
  md += `• Freeze Authority: ${data.freezeAuthority ? `⚠️ \`${data.freezeAuthority}\`` : "✅ Revoked"}\n`;
  
  if (data.recentMintEvents && data.recentMintEvents.mints && data.recentMintEvents.mints.length) {
    md += `• Recent mint events: ⚠️ ${data.recentMintEvents.mints.length} detected\n`;
  } else {
    md += `• Recent mint events: ✅ None detected\n`;
  }
  
  return { summaryMarkdown: md };
}

function formatFullReport(mint, data, score) {
  const { formatNumber, formatUSD } = require('./marketData');
  
  let md = `🔍 *COMPREHENSIVE TOKEN ANALYSIS*\n\n`;
  
  // === BASIC TOKEN INFO ===
  md += `📊 *BASIC INFORMATION*\n`;
  md += `• Token Name: ${data.marketData?.name || data.metadata?.name || 'Unknown'}\n`;
  md += `• $TICKER: ${data.marketData?.symbol || data.metadata?.symbol || 'N/A'}\n`;
  md += `• Token Contract: \`${mint}\`\n`;
  md += `• Decimals: ${data.decimals || data.technicalData?.decimals || 'N/A'}\n`;
  
  // === MARKET DATA ===
  md += `\n💰 *MARKET DATA*\n`;
  md += `• Price: ${data.marketData?.priceUsd ? formatUSD(data.marketData.priceUsd) : 'N/A'}\n`;
  md += `• Market Cap: ${data.marketData?.marketCap ? formatUSD(data.marketData.marketCap) : 'N/A'}\n`;
  md += `• FDV: ${data.marketData?.fdv ? formatUSD(data.marketData.fdv) : 'N/A'}\n`;
  md += `• ATH MCAP: N/A\n`; // Not available in current APIs
  
  // === LIQUIDITY & VOLUME ===
  md += `\n💧 *LIQUIDITY & TRADING*\n`;
  md += `• Liquidity: ${data.marketData?.liquidity?.usd ? formatUSD(data.marketData.liquidity.usd) : 'N/A'}\n`;
  md += `• Volume (24h): ${data.marketData?.volume?.h24 ? formatUSD(data.marketData.volume.h24) : 'N/A'}\n`;
  md += `• Total Txns (24h): ${data.marketData?.txns?.h24?.total || 'N/A'}\n`;
  md += `• Total Buys (24h): ${data.marketData?.txns?.h24?.buys || 'N/A'}\n`;
  md += `• Total Sells (24h): ${data.marketData?.txns?.h24?.sells || 'N/A'}\n`;
  md += `• Txns Makers: ${data.holderAnalysis?.freshWallets || 'N/A'}\n`;
  
  // === TOKEN DETAILS ===
  md += `\n🔧 *TOKEN DETAILS*\n`;
  md += `• Token Age: ${data.technicalData?.age?.formatted || data.marketData?.age?.formatted || 'Unknown'}\n`;
  md += `• Total Supply: ${data.supply ? formatTokenAmount(data.supply, data.decimals || 0) : 'N/A'}\n`;
  md += `• Token Program: ${data.technicalData?.tokenProgram || 'Unknown'}\n`;
  
  // === SOCIAL LINKS ===
  md += `\n🌐 *LINKS & SOCIAL*\n`;
  md += `• Website: ${data.socialData?.website || 'N/A'}\n`;
  md += `• Twitter: ${data.socialData?.twitter || 'N/A'}\n`;
  md += `• DexScreener: ${data.socialData?.dexScreenerUrl || data.marketData?.url || 'N/A'}\n`;
  
  // === SECURITY ANALYSIS ===
  md += `\n🔒 *SECURITY ANALYSIS*\n`;
  md += `• Mint Authority: ${data.mintAuthority ? `⚠️ \`${data.mintAuthority}\`` : "✅ Revoked"}\n`;
  md += `• Freeze Authority: ${data.freezeAuthority ? `⚠️ \`${data.freezeAuthority}\`` : "✅ Revoked"}\n`;
  md += `• Token Dev Address: ${data.holderAnalysis?.devWallet?.address ? `\`${data.holderAnalysis.devWallet.address}\`` : 'Unknown'}\n`;
  md += `• Paid DEX: ${data.marketData?.dexId === 'raydium' ? 'Yes' : data.marketData?.dexId ? 'Yes' : 'Unknown'}\n`;
  
  // === LIQUIDITY POOL ANALYSIS ===
  md += `\n🏊 *LIQUIDITY POOL ANALYSIS*\n`;
  md += `• Pool Address: ${data.marketData?.pairAddress ? `\`${data.marketData.pairAddress}\`` : 'N/A'}\n`;
  md += `• DEX Used: ${data.marketData?.dexId?.toUpperCase() || 'Unknown'}\n`;
  md += `• USD Pairing: ${data.marketData ? 'Yes' : 'Unknown'}\n`;
  md += `• Liquidity Locked: ${data.liquidityAnalysis?.isLiquidityLocked || 'Unknown'}\n`;
  md += `• Pool Age: ${data.marketData?.pairCreatedAt ? formatAge((Date.now() / 1000 - data.marketData.pairCreatedAt) / 3600) : 'Unknown'}\n`;
  
  // === HOLDER ANALYSIS ===
  md += `\n👥 *HOLDER ANALYSIS*\n`;
  md += `• Top 1 Holder: ${data.topHoldersPercent?.top1 ? data.topHoldersPercent.top1.toFixed(2) + '%' : 'N/A'}\n`;
  md += `• Top 5 Holders: ${data.topHoldersPercent?.top5 ? data.topHoldersPercent.top5.toFixed(2) + '%' : 'N/A'}\n`;
  md += `• Top 10 Holders: ${data.topHoldersPercent?.top10 ? data.topHoldersPercent.top10.toFixed(2) + '%' : 'N/A'}\n`;
  md += `• Fresh Wallets: ${data.holderAnalysis?.freshWallets || 0}\n`;
  md += `• Suspicious Patterns: ${data.holderAnalysis?.suspiciousPatterns?.length || 0}\n`;
  
  // === CLUSTER ANALYSIS ===
  if (data.holderAnalysis?.clusterAnalysis?.clustersFound > 0) {
    md += `• Wallet Clusters: ⚠️ ${data.holderAnalysis.clusterAnalysis.clustersFound} detected\n`;
  } else {
    md += `• Wallet Clusters: ✅ None detected\n`;
  }
  
  // === TRADING PATTERNS ===
  md += `\n📈 *TRADING PATTERNS*\n`;
  if (data.marketData?.priceChange) {
    md += `• 24h Change: ${data.marketData.priceChange.h24 > 0 ? '📈' : '📉'} ${data.marketData.priceChange.h24?.toFixed(2) || 'N/A'}%\n`;
  }
  md += `• Recent Mint Events: ${data.recentMintEvents?.mints?.length || 0}\n`;
  
  // === HONEYPOT & SECURITY ===
  md += `\n🍯 *HONEYPOT & SECURITY CHECKS*\n`;
  md += `• Can Sell: ${data.tradingAnalysis?.canSell === true ? '✅ Yes' : data.tradingAnalysis?.canSell === false ? '❌ No' : '⚠️ Unknown'}\n`;
  md += `• Honeypot Risk: ${data.tradingAnalysis?.honeypotRisk === 'low' ? '✅ Low' : data.tradingAnalysis?.honeypotRisk === 'high' ? '❌ High' : '⚠️ ' + (data.tradingAnalysis?.honeypotRisk || 'Unknown')}\n`;
  
  if (data.tradingAnalysis?.tradingRestrictions?.length > 0) {
    md += `• Trading Issues: ⚠️ ${data.tradingAnalysis.tradingRestrictions.join(', ')}\n`;
  } else {
    md += `• Trading Issues: ✅ None detected\n`;
  }
  
  // === RISK SCORE ===
  md += `\n⚠️ *OVERALL RISK ASSESSMENT*\n`;
  md += `• Risk Score: *${score}/100*\n`;
  
  if (score >= 80) {
    md += `• Recommendation: ❌ *DO NOT BUY* - HIGH RISK\n`;
  } else if (score >= 60) {
    md += `• Recommendation: ⚠️ *EXERCISE EXTREME CAUTION*\n`;
  } else if (score >= 40) {
    md += `• Recommendation: ⚠️ *PROCEED WITH CAUTION*\n`;
  } else {
    md += `• Recommendation: ✅ *RELATIVELY SAFE*\n`;
  }
  
  // === SUSPICIOUS ACTIVITY SUMMARY ===
  if (data.holderAnalysis?.suspiciousPatterns?.length > 0) {
    md += `\n🚨 *SUSPICIOUS ACTIVITY DETECTED*\n`;
    for (const pattern of data.holderAnalysis.suspiciousPatterns.slice(0, 3)) {
      md += `• Wallet #${pattern.rank}: ${pattern.flags.join(', ')}\n`;
    }
  }
  
  return { fullReportMarkdown: md, summaryMarkdown: md };
}

// Helper function to format token amounts with proper decimals
function formatTokenAmount(amountRaw, decimals) {
  try {
    const Decimal = require("decimal.js");
    const rawAmount = new Decimal(amountRaw);
    const divisor = new Decimal(10).pow(decimals);
    const amount = rawAmount.div(divisor);
    
    const amountNum = amount.toNumber();
    if (amountNum >= 1e9) {
      return `${amount.div(1e9).toFixed(2)}B`;
    } else if (amountNum >= 1e6) {
      return `${amount.div(1e6).toFixed(2)}M`;
    } else if (amountNum >= 1e3) {
      return `${amount.div(1e3).toFixed(2)}K`;
    }
    return amount.toFixed(decimals > 0 ? Math.min(decimals, 4) : 0);
  } catch (e) {
    return amountRaw || 'N/A';
  }
}

// Calculate percentage held by top N holders
function calculateTopHoldersPercent(topHolders, topN, totalSupply, decimals) {
  try {
    const Decimal = require("decimal.js");
    const topNHolders = topHolders.slice(0, topN);
    const totalTopAmount = topNHolders.reduce((sum, holder) => {
      return sum.plus(new Decimal(holder.amountRaw || holder.tokenAmount || 0));
    }, new Decimal(0));
    
    const supply = new Decimal(totalSupply);
    if (supply.eq(0)) return 0;
    
    return totalTopAmount.div(supply).mul(100).toNumber();
  } catch (e) {
    return 0;
  }
}

// Helper function to format age
function formatAge(ageInHours) {
  if (ageInHours < 1) {
    return `${Math.floor(ageInHours * 60)} minutes`;
  } else if (ageInHours < 24) {
    return `${Math.floor(ageInHours)} hours`;
  } else if (ageInHours < 24 * 7) {
    return `${Math.floor(ageInHours / 24)} days`;
  } else if (ageInHours < 24 * 30) {
    return `${Math.floor(ageInHours / (24 * 7))} weeks`;
  } else {
    return `${Math.floor(ageInHours / (24 * 30))} months`;
  }
}

module.exports = { computeScore, formatSummary, formatFullReport };
